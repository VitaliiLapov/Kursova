PING - #ping or #p;
ECHO - #echo:     ;
GENERATION - #generation: p-< Шлях до файлу > n-< назва файлу . формат > ;
PROCESS - #process: r-<Шлях до файлу з випадковими даними> s-<Шлях до файлу для збереження результатів обробки>;